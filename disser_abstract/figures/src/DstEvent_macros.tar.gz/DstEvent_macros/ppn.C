// Author: Jan Musinsky
// 08/04/2010

void ppn()
{
  TLorentzVector spectator, recoil, scattering;
  Double_t t, theta_spec, theta_reco, theta_max = 5.0;
  TLorentzVector target(0,0,0,mass_p);
  TH1F *h01 = new TH1F("h01","",100,0,3);
  TH1F *h02 = new TH1F("h02","",100,0,3);
  TH1F *h11 = new TH1F("h11","",100,0,1.2);
  TH1F *h12 = new TH1F("h12","",100,0,1.2);
  TH1F *h21 = new TH1F("h21","",80,0,0.8);
  TH1F *h22 = new TH1F("h22","",80,0,0.8);
  TH1F *h31 = new TH1F("h31","",30,0.999,1);
  TH1F *h32 = new TH1F("h32","",30,0.999,1);
  TH1F *h41 = new TH1F("h41","",100,0.0,0.8);
  TH1F *h42 = new TH1F("h42","",100,0.0,0.8);
  TH1F *h5  = new TH1F("h5","",50,-180,180);
  TH1F *h61 = new TH1F("h61","",100,0,1.75);
  TH1F *h62 = new TH1F("h62","",100,0,1.75);
  TH1F *h63 = new TH1F("h63","",100,0,1.75);
  TH2F *h2  = new TH2F("h2","",100,0.0,9.0,100,0.0,0.3);

  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    tree->GetEntry(i);
    spectator  = event->ALabType(TDstEvent::kSpec);
    recoil     = event->ALabType(TDstEvent::kReco);
    scattering = event->ALabType(TDstEvent::kScat);
    t = -((target - event->Lab(3))*(target - event->Lab(3))); // target - n
    theta_spec = event->LabType(TDstEvent::kSpec).Theta()*TMath::RadToDeg();
    theta_reco = event->LabType(TDstEvent::kReco).Theta()*TMath::RadToDeg();
    h61->Fill(spectator.P());
    h62->Fill(recoil.P());
    h63->Fill(scattering.P());
    h2->Fill(theta_spec, spectator.P());
    if (recoil.P() > 0.4)
      // for more isotropic => p > 0.4, but this is "bluff"
      // for more isotropic => protons + neuterons, but should it only protons
      h5->Fill(recoil.Phi()*TMath::RadToDeg());

    if (!(elist->GetIndex(i) != -1)) { // charge retention
      h01->Fill(t);
      h42->Fill(spectator.P());
      continue;
    }
    h02->Fill(t);
    h11->Fill(spectator.P());
    h12->Fill(recoil.P());
    h41->Fill(spectator.P());
    if ((theta_spec > theta_max) || (theta_reco > theta_max)) continue;
    h21->Fill(spectator.P());
    h22->Fill(recoil.P());
    h31->Fill(event->LabType(TDstEvent::kSpec).CosTheta());
    h32->Fill(event->LabType(TDstEvent::kReco).CosTheta());
  }

  gStyle->SetOptStat(0);
  can = new TCanvas("chex_ret_t","",0,0,600,350);
  h02->GetXaxis()->SetTitle("#left|t#right|, (GeV/c)^{2}");
  h02->GetYaxis()->SetTitle("entries");
  h02->GetYaxis()->CenterTitle();
  h02->GetYaxis()->SetTitleOffset(1.30);
  h02->GetYaxis()->SetNdivisions(409);
  h02->SetFillColor(kGray);
  h02->SetMaximum(h01->GetMaximum()*1.05);
  h02->Draw(); h01->Draw("same");
  leg = new TLegend(0.20,0.65,0.45,0.80);
  leg->SetTextSize(0.04);
  leg->AddEntry(h02,"   d p  #rightarrow  (p p) n");
  leg->AddEntry(h01,"   d p  #rightarrow  (p n) p");
  leg->SetFillColor(0);
  leg->Draw();
  printTeX("chex_ret_t-abs");

  can = new TCanvas("theta_p","",0,0,640,640);
  h2->GetXaxis()->SetTitle("#theta, degree");
  h2->GetYaxis()->SetTitle("p_{spec}, GeV/c");
  h2->GetYaxis()->CenterTitle();
  h2->GetYaxis()->SetTitleOffset(1.20);
  h2_1 = h2->ProjectionY("h2_1"); // h2_1->Rebin();
  h2_1->GetXaxis()->SetTitle("p_{spec}, GeV/c");
  h2_1->GetXaxis()->CenterTitle(kFALSE);
  h2_1->GetYaxis()->SetNdivisions(405); h2_1->GetYaxis()->SetLabelSize(0.045);
  h2_1->GetXaxis()->SetNdivisions(405);
  h2_1->GetXaxis()->SetTitleSize(0.06); h2_1->GetXaxis()->SetLabelSize(0.055);
  h2_2 = h2->ProjectionX("h2_2"); // h2_2->Rebin();
  h2_2->GetXaxis()->SetTitle("#theta, degree");
  h2_2->GetYaxis()->SetNdivisions(405); h2_2->GetYaxis()->SetLabelSize(0.045);
  h2_2->GetXaxis()->SetNdivisions(308);
  h2_2->GetXaxis()->SetTitleSize(0.06); h2_2->GetXaxis()->SetLabelSize(0.055);
  Double_t max = TMath::Max(h2_1->GetMaximum(), h2_2->GetMaximum())*1.075;
  h2_1->SetMaximum(max); h2_2->SetMaximum(max);
  h2_1->SetMinimum(1); h2_2->SetMinimum(1);
  can_1 = new TPad("theta_p_1","",0.0,0.40,1.0,1.0);
  can_1->Draw(); can_1->cd(); can_1->SetTopMargin(0.08); h2->Draw();
  can_1->SetGridx(); can_1->SetGridy();
  can->cd();
  can_2 = new TPad("theta_p_2","",0.0,0.0,1.0,0.40);
  can_2->Draw(); can_2->cd();
  can_21 = new TPad("theta_p_21","",0.0,0.0,0.5,1.0);
  can_21->Draw(); can_21->cd();
  can_21->SetTopMargin(0.00); can_21->SetBottomMargin(0.15);
  can_21->SetLeftMargin(0.075); can_21->SetRightMargin(0.075);
  h2_1->Draw();
  can_2->cd();
  can_22 = new TPad("theta_p_22","",0.5,0.0,1.0,1.0);
  can_22->Draw(); can_22->cd();
  can_22->SetTopMargin(0.00); can_22->SetBottomMargin(0.15);
  can_22->SetLeftMargin(0.075); can_22->SetRightMargin(0.075);
  h2_2->Draw();
  can->cd();
  printTeX("theta_p-abs");
  can->Print("theta_p-abs.png");
}
