// Author: Jan Musinsky
// 01/04/2010

void dp_two_protons()
{
  Double_t theta_max = 4.633;
  TH1F *h1 = new TH1F("h1","",10,0.0,theta_max);
  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    if (elist->GetIndex(i) == -1) continue; // only charge exchange
    tree->GetEntry(i);
    // in chex event spectator is always proton
    h1->Fill(event->LabType(TDstEvent::kSpec).Theta()*TMath::RadToDeg());
  }

  // two protons (only one conus < theta_max)
  TH1F *h2 = new TH1F("h2",Form("cone (0 -> %5.3f)", theta_max),10,0.00,0.01);
  TLorentzVector target(0,0,0,mass_p);
  Double_t t, cone1, cone2;
  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    if (elist->GetIndex(i) == -1) continue; // only charge exchange
    tree->GetEntry(i);
    // for t ~ 0.0 only charge exchange entries, t = (target - neuteron)^2
    t = TMath::Abs((target - event->Lab(3))*(target - event->Lab(3)));
    cone1 = event->Lab(1).Theta()*TMath::RadToDeg(); // first proton
    cone2 = event->Lab(2).Theta()*TMath::RadToDeg(); // second proton
    if ((cone1 < theta_max) && (cone2 < theta_max)) h2->Fill(t);
  }

  // total entries (237413 + 10585)  = 247998
  // total cross section             = 82.889 +- 0.063
  // chex entries                    = 17512
  // chex cross section              = 5.85308 +- 0.0459807
  Double_t bin_c, bin_e, bin2_c, bin2_e;
  Double_t norm_c = h1->GetEntries()/h1->Integral();
  Double_t norm_e = norm_c*TMath::Sqrt(1.0/h1->GetEntries() +
                                       1.0/h1->Integral());
  Double_t norm_tmp = (norm_e/norm_c)*(norm_e/norm_c);
  Double_t mb = (82.889/(247998*h2->GetBinWidth(0)));
  Double_t mb_e = mb*TMath::Sqrt((0.063/82.889)*(0.063/82.889) + 1.0/247889);
  Double_t mb_tmp = (mb_e/mb)*(mb_e/mb);
  for (Int_t ib = 1; ib <= h2->GetNbinsX(); ib++) {
    bin_c = h2->GetBinContent(ib);
    bin_e = h2->GetBinError(ib);
    bin2_c = bin_c*mb*norm_c;
    bin2_e = 0.0;
    if (bin_c != 0)
      bin2_e = bin2_c*TMath::Sqrt((bin_e/bin_c)*(bin_e/bin_c) +
                                  mb_tmp + norm_tmp);
    h2->SetBinContent(ib, bin2_c); // wrong histogram statistics
    h2->SetBinError(ib, bin2_e);
  }

  gStyle->SetOptStat(0);
  new TCanvas("dp_two_protons","",0,0,600,350);
  TF1 *fite = new TF1("fite","[0]*TMath::Exp([1]*x+[2]*x*x)");
  fite->SetLineWidth(1);
  h2->Fit(fite, "Q");
  Double_t t0 = fite->Eval(0); // same as parameter [0]
  Double_t p0 = fite->GetParameter(0), p0_e = fite->GetParError(0);
  // equation for calculating error in dSigma/dt is correct only for t=0
  Printf("dSigma/dt(t=0) = %f +- %f", t0, t0*TMath::Sqrt((p0_e*p0_e)/(p0*p0)));

  h2->SetTitle(0); h2->SetMinimum(0); h2->SetMaximum(40);
  h2->GetXaxis()->SetTitle("#left|t#right|, (GeV/c)^{2}");
  h2->GetXaxis()->SetNdivisions(309);
  h2->GetYaxis()->SetTitle("#frac{d#sigma}{dt}, #frac{mb}{(GeV/c)^{2}}");
  h2->GetYaxis()->CenterTitle(); h2->GetYaxis()->SetTitleOffset(1.08);
  h2->GetYaxis()->SetNdivisions(905);
  printTeX("dp_two_protons-abs");
}
