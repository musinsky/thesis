// -*- mode: c++ -*-
// Author: Jan Musinsky <mailto:mucha@sunhe.jinr.ru>
// @(#) 28 Oct 2009

#ifndef DSTEVENT_TDstEvent
#define DSTEVENT_TDstEvent

#ifndef ROOT_TClonesArray
#include <TClonesArray.h>
#endif

#ifndef DSTEVENT_TDstTrack
#include "TDstTrack.h"
#endif

class TDstEvent : public TObject {

private:
  Double_t      fFlag;    // flag of polarization (-1 = no, +1 = yes)
  Double_t      fLab;     // lab-exp-index ( = lab*10**4 + exp.no)
  Double_t      fWeight;  // weight
  Double_t      fRoll;    // roll
  Double_t      fHyp;     // no of hyp. (-1 = no fit, + 1 = fit)
  Int_t         fNTracks;  // number of tracks
  TClonesArray *fTracks;  //->arry with all tracks

public:
  // TDstEvent nucleon indexing (only ppn reaction)
  enum {
    // !!! change in october 2009 !!!
    kSpec = 0, // spectator  = most slowly
    kReco = 1, // recoil     = amid, all in ALab
    kScat = 2  // scattering = most quickly
  };
  TDstEvent();
  virtual       ~TDstEvent();

  Double_t      GetFlag() const { return fFlag; }
  Double_t      GetLab() const { return fLab; }
  Double_t      GetWeight() const { return fWeight; }
  Double_t      GetRoll() const { return fRoll; }
  Double_t      GetHyp() const { return fHyp; }
  Int_t         GetNTracks() const { return fNTracks; }
  TClonesArray *DstTracks() const { return fTracks; }

  virtual void Clear(Option_t *option = "");
  void         AddTrack(const Double_t xl, const Double_t xa, const Double_t xc,
                        const Double_t y,  const Double_t z,  const Double_t m);
  void         DstToTree(const char *fname);

  TDstTrack     *GetTrack(const Int_t it) const { return (it < fNTracks) ?
      (TDstTrack*)fTracks->UncheckedAt(it) : 0; }
  TLorentzVector Lab(const Int_t ip) const { return (GetTrack(ip)) ?
      GetTrack(ip)->Lab() : TLorentzVector(); }
  TLorentzVector ALab(const Int_t ip) const { return (GetTrack(ip)) ?
      GetTrack(ip)->ALab() : TLorentzVector(); }
  TLorentzVector CMS(const Int_t ip) const { return (GetTrack(ip)) ?
      GetTrack(ip)->CMS() : TLorentzVector(); }

  // only ppn reaction
  Int_t          FindType(const Int_t rank) const; // find only in ALab
  TLorentzVector LabType(const Int_t r) const { return Lab(FindType(r)); }
  TLorentzVector ALabType(const Int_t r) const { return ALab(FindType(r)); }
  TLorentzVector CMSType(const Int_t r) const { return CMS(FindType(r)); }

  ClassDef(TDstEvent,1) // DstEvent class
};

#endif
