// -*- mode: c++ -*-
// Author: Jan Musinsky <mailto:mucha@sunhe.jinr.ru>
// @(#) 27 Jul 2009

#include "TDstTrack.h"

ClassImp(TDstTrack)

//______________________________________________________________________________
TDstTrack::TDstTrack(const Double_t pxl, const Double_t pxa, const Double_t pxc,
                     const Double_t pyc, const Double_t pzc,
		     const Double_t mass)
{
  // Dst X, Y, Z <=> Z, X, Y our coordinate system
  fPx    = pyc; fPy     = pzc; fMass  = mass;
  fPzLab = pxl; fPzALab = pxa; fPzCMS = pxc;
}
