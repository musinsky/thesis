// -*- mode: c++ -*-
// Author: Jan Musinsky <mailto:mucha@sunhe.jinr.ru>
// @(#) 28 Oct 2009

////////////////////////////////////////////////////////////////////////////////
// Mini(micro)-format dp 3.35 Gev/c
// --------------------------------
//
// all2pr.dst     dp exp. 3.35 Gev/c     125673 events
//    2 lucove (nabojove), okrem stavu "p p n" (ktoreho kanal je zapisany
//    v subore allppn) su v koncovom stave este nejake 2 nabite castice
//    napr: "d p pi0" alebo "d p" (pruzny rozptyl)
// all4pr.dst     dp exp. 3.35 Gev/c     8962   events
//    4 lucove (nabojove) castice v koncovom stave, napr: "p p p pi-"
//    pozor na zakon zachovania naboja
// allppn.dst     dp exp. 3.35 Gev/c     102778 events
//    v koncovom stave mame iba "p p n"
//
// kazda dst ma mierne odlisny format zapisu
//
// Mini(micro) for dp experiment    version 12.10.1987
// ---------------------------------------------------
//                D + P  ->  P + P + N
//
//                 **** HEADING ****
// 1.FLAG OF POLARIZATION (-1 = NO,+1 = YES)
//    bolo niekolko seansov (asi 2) s polarizovanym zvazkom deuteronov
//    ak bola poarizacia, tak znak iny ako -1, t.j. +1 (+2)
// 2.LAB-EXP-INDEX ( = LAB*10**4 + EXP.NO)
//    pre vnutorne potreby (labak, expozica)
// 3.WEIGHT
//    analyza sa vykonavala urcitym kinematickym programom, ktory pocital rozne
//    parametre danej reakcie.
//    weight = 1.00 jednoznacny (kinematicky) kanal "p p n"
//    weight = 0.50 boli dve moznosti: "p p n" a napr. "d p pi0" v tomto pripade
//             "d" a "p" mozu mat priblizne rovnake impulsy, tazko rozlisit
//             deuteron od protona. Mozu byt aj tzv. konkurujuce kanaly
//             t.j. ten isty pripad moze byt aj v allppn aj all2pr dst files.
//    weight = 0.33 v niektorych prvych runoch bol problem s "vyseparovanim"
//             cisteho zvazku deuteronov (ten bol sekundarnym produktom) a tak
//             okrem deuteronov letela este aj primes s protonmi takze boli
//             az tri moznosti v koncovom stave: t.j pribudla  napr. moznost
//             "p p ?" - pruzny rozptyl "primesoveho protonu". Tak isto moznost
//             konkurujucich kanalov.
// 4.ROLL
//    cislo plonki, pre vnutorne potreby. Ak bola -99 tak primes protonov
//    vo zvazku, t.j. korelacia s weight = 0.33 (malo takych pripadov)
//
//               **** TRACK REGION ****
//                      INC P  P  N
// 1.PX LAB.SYST.       5   11 17 23
// 2.PX ALAB.SYST.      6   12 18 24
// 3.PX*      CM        7   13 19 25
// 4.PY*    SYSTEM      8   14 20 26
// 5.PZ*                9   15 21 27
// 6.MASS               10  16 22 28
//
// ARRAY(10) = mass of deuteron
// FORMAT(I9,4(2X,F10.2),/6(2X,F10.5))
//
// 1. px v lab systeme, zvazok (deuteron) urcuje suradnicovu sustavu
//    os zvazku je os x a preto py a pz pre zvazok = 0
// 2. px v alab systeme <=> system pokoja deuterona, "nalietavajuci" proton
//    ma impulz v alab stale zaporny, impulz deuterona = 0
// 3. px* v CMS <=> taziskovy system
// 4. py* je invariant vo vsetkych 3 systemoch
// 5. pz* je invariant vo vsetkych 3 systemoch
// 6. hmotnost !!! hmotnosti tych istych castic sa nepatrne lisia !!!

#include <TSystem.h>
#include <Riostream.h>
#include <TFile.h>
#include <TTree.h>
#include <TEventList.h>

#include "TDstEvent.h"

ClassImp(TDstEvent)

//______________________________________________________________________________
TDstEvent::TDstEvent()
{
  // Info("TDstEvent","Constructor");
  fFlag = fLab = fWeight = fRoll = fHyp = 9999;
  fNTracks = 0;
  fTracks  = new TClonesArray("TDstTrack",4);
}
//______________________________________________________________________________
TDstEvent::~TDstEvent()
{
  // Info("~TDstEvent","Destructor");
  Clear("C");
  delete fTracks;
  fTracks = 0;
}
//______________________________________________________________________________
void TDstEvent::Clear(Option_t *option)
{
  fNTracks = 0;
  fTracks->Clear(option);
}
//______________________________________________________________________________
void TDstEvent::AddTrack(const Double_t xl, const Double_t xa,
                         const Double_t xc, const Double_t y,  const Double_t z,
                         const Double_t m)
{
  TClonesArray &tracks = *fTracks;
  new(tracks[fNTracks++]) TDstTrack(xl,xa,xc,y,z,m);
}
//______________________________________________________________________________
void TDstEvent::DstToTree(const char *fname)
{
  /* create tree(root) from dst(ASCII):
     gSystem->Load("libPhysics.so");
     gSystem->Load("libTree.so");
     gSystem->Load("lib/libDstEvent.so");
     TDstEvent *dst_e = new TDstEvent;
     dst_e->DstToTree("/free1/dst/dp/allppn.dst");
  */

  TString fout = gSystem->BaseName(fname);
  Int_t head = 0;
  if (fout.BeginsWith("all2pr") || fout.BeginsWith("all4pr")) head = 5;
  else if (fout.BeginsWith("allppn")) head = 4;
  if (head == 0) {
    Error("DstToTree","Suspect name of file: %s",fname);
    return;
  }
  fout.Remove(6); fout.Append(".root");

  ifstream fin(fname);
  if (!fin) {
    Printf("Cannot read file: %s",fname);
    return;
  }

  TFile *file = new TFile(fout.Data(),"recreate");
  TTree *tree = new TTree("dpDst",Form("%s MiniDst",fout.Remove(6).Data()));
  TDstEvent *event = this;
  tree->Branch("DstEvent","TDstEvent",&event);

  // event list with charge exchange entries (only for allppn)
  TEventList *elist = 0;
  if (head == 4)
    elist = new TEventList("chex","n is the most quickly in ALab");

  Int_t nw = 0, maxTrack = 41; // 5 + 6*6 for all4pr dst
  Double_t val[maxTrack];

  while(kTRUE) {
    Clear();
    fin >> nw; // number of word in one event
    if (!fin.good()) break;
    if (nw > maxTrack) {
      Error("DstToTree","To many tracks %d",nw);
      return;
    }
    for (Int_t iw = 0; iw < nw; iw++) fin >> val[iw]; // one event

    fFlag   = val[0];
    fLab    = val[1];
    fWeight = val[2];
    fRoll   = val[3];
    if (head == 5)
      fHyp  = val[4];

    for (Int_t t = 0; t < (nw-head)/6; t++)
      event->AddTrack(val[head+0+(6*t)],val[head+1+(6*t)],val[head+2+(6*t)],
                      val[head+3+(6*t)],val[head+4+(6*t)],val[head+5+(6*t)]);

    // chex <=> in ALab frame neuteron = fTracks[3] is the most quickly
    if (elist)
      if (FindType(2) == 3)
        elist->Enter(tree->GetEntries());
    tree->Fill();
  }

  Printf("Found %lld events",tree->GetEntries());
  tree->Write();
  if (elist) {
    Printf("Found %i charge exchange events",elist->GetN());
    elist->Write();
  }
  fin.close();
  delete file; // trees and event lists are owned by current directory
}
//______________________________________________________________________________
Int_t TDstEvent::FindType(const Int_t rank) const
{
  // only ppn reaction
  //
  // AntiLab system (deuteron, beam rest frame)
  // rank = 0 => most slowly  => spectator
  // rank = 1 => amid         => recoil
  // rank = 2 => most quickly => scattering
  //
  // !!! pozor zmena, october 2009 !!!
  // recoil <-> scattering => pred zmenou bolo chybne urcovanie typu nuklona
  // !!! rank = 1 => amid         => scattering !!! nespravne
  // !!! rank = 2 => most quickly => recoil     !!! nespravne
  //
  // urcovanie typu nuklona iba v ALab systeme
  // analogicky by mohol byt spectator v Lab najrychlejsi nuklon
  // ale ALab sa viac vydeluje medzi ostatnymi nuklonami
  // analogicky chex v Lab by mohol byt event, kde je neuteron najpomalsi
  // ale opat sa mozu nukleony premiesat

  if (rank < 0 || rank > 2) {
    Error("FindType","Bad index (%d)",rank);
    return 9999;
  }
  Double_t beta[3] = {ALab(1).Beta(), ALab(2).Beta(), ALab(3).Beta()}; // p,p,n
  Int_t sort[3];
  TMath::Sort(3, beta, sort, kFALSE);
  return (sort[rank] + 1); // 0 is beam, d
}
