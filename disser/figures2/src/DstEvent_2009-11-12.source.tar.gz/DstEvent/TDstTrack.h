// -*- mode: c++ -*-
// Author: Jan Musinsky <mailto:mucha@sunhe.jinr.ru>
// @(#) 27 Jul 2009

#ifndef DSTEVENT_TDstTrack
#define DSTEVENT_TDstTrack

#ifndef ROOT_TLorentzVector
#include <TLorentzVector.h>
#endif

class TDstTrack : public TObject {

private:
  Double_t      fPx;     // px (invariant in all systems)
  Double_t      fPy;     // py (invariant in all systems)
  Double_t      fPzLab;  // pz in Lab
  Double_t      fPzALab; // pz in ALab
  Double_t      fPzCMS;  // pz in CMS
  Double_t      fMass;   // mass

public:
  TDstTrack() {;}
  TDstTrack(const Double_t pxl, const Double_t pxa, const Double_t pxc,
            const Double_t pyc, const Double_t pzc, const Double_t mass);
  virtual       ~TDstTrack() {;}

  Double_t      Px() const { return fPx; }
  Double_t      Py() const { return fPy; }
  Double_t      PzLab() const { return fPzLab; }
  Double_t      PzALab() const { return fPzALab; }
  Double_t      PzCMS() const { return fPzCMS; }
  Double_t      Mass() const { return fMass; }

  TVector3      Lab3() const { return TVector3(fPx, fPy, fPzLab); }
  TVector3      ALab3() const { return TVector3(fPx, fPy, fPzALab); }
  TVector3      CMS3() const { return TVector3(fPx, fPy, fPzCMS); }

  TLorentzVector Lab() const { return
      TLorentzVector(Lab3(), TMath::Sqrt(Lab3().Mag2() + fMass*fMass)); }
  TLorentzVector ALab() const { return
      TLorentzVector(ALab3(), TMath::Sqrt(ALab3().Mag2() + fMass*fMass)); }
  TLorentzVector CMS() const { return
      TLorentzVector(CMS3(), TMath::Sqrt(CMS3().Mag2() + fMass*fMass)); }

  ClassDef(TDstTrack,1) // DstTrack class
};

#endif
