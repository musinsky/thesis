// Author: Jan Musinsky
// 12/11/2009

void ppn()
{
  TLorentzVector spectator, recoil, scattering;
  Double_t t, theta_spec, theta_reco, theta_max = 5.0;
  TLorentzVector target(0,0,0,mass_p);
  TH1F *h01 = new TH1F("h01","",100,0,3);
  TH1F *h02 = new TH1F("h02","",100,0,3);
  TH1F *h11 = new TH1F("h11","",100,0,1.2);
  TH1F *h12 = new TH1F("h12","",100,0,1.2);
  TH1F *h21 = new TH1F("h21","",80,0,0.8);
  TH1F *h22 = new TH1F("h22","",80,0,0.8);
  TH1F *h31 = new TH1F("h31","",30,0.999,1);
  TH1F *h32 = new TH1F("h32","",30,0.999,1);
  TH1F *h41 = new TH1F("h41","",100,0.0,0.8);
  TH1F *h42 = new TH1F("h42","",100,0.0,0.8);
  TH1F *h5  = new TH1F("h5","",50,-180,180);
  TH1F *h61 = new TH1F("h61","",100,0,1.75);
  TH1F *h62 = new TH1F("h62","",100,0,1.75);
  TH1F *h63 = new TH1F("h63","",100,0,1.75);
  TH2F *h2  = new TH2F("h2","",150,0.0,9.0,150,0.0,0.3);

  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    tree->GetEntry(i);
    spectator  = event->ALabType(TDstEvent::kSpec);
    recoil     = event->ALabType(TDstEvent::kReco);
    scattering = event->ALabType(TDstEvent::kScat);
    t = -((target - event->Lab(3))*(target - event->Lab(3))); // target - n
    theta_spec = event->LabType(TDstEvent::kSpec).Theta()*TMath::RadToDeg();
    theta_reco = event->LabType(TDstEvent::kReco).Theta()*TMath::RadToDeg();
    h61->Fill(spectator.P());
    h62->Fill(recoil.P());
    h63->Fill(scattering.P());
    h2->Fill(theta_spec, spectator.P());
    if (recoil.P() > 0.4)
      // for more isotropic => p > 0.4, but this is "bluff"
      // for more isotropic => protons + neuterons, but should it only protons
      h5->Fill(recoil.Phi()*TMath::RadToDeg());

    if (!(elist->GetIndex(i) != -1)) { // charge retention
      h01->Fill(t);
      h42->Fill(spectator.P());
      continue;
    }
    h02->Fill(t);
    h11->Fill(spectator.P());
    h12->Fill(recoil.P());
    h41->Fill(spectator.P());
    if ((theta_spec > theta_max) || (theta_reco > theta_max)) continue;
    h21->Fill(spectator.P());
    h22->Fill(recoil.P());
    h31->Fill(event->LabType(TDstEvent::kSpec).CosTheta());
    h32->Fill(event->LabType(TDstEvent::kReco).CosTheta());
  }

  gStyle->SetOptStat(0);
  new TCanvas();
  h01->GetXaxis()->SetTitle("#left|t#right|, (GeV/c)^{2}");
  h01->GetYaxis()->SetTitle("entries");
  h01->GetYaxis()->CenterTitle();
  h01->GetYaxis()->SetTitleOffset(1.30);
  h01->GetYaxis()->SetNdivisions(409);
  h02->SetFillColor(1);
  h02->SetFillStyle(3003);
  h01->Draw(); h02->Draw("same");
  leg = new TLegend(0.17,0.65,0.47,0.80);
  leg->AddEntry(h01,"charge retention");
  leg->AddEntry(h02,"charge exchange");
  leg->SetFillColor(0);
  leg->Draw();
  printTeX("chex_ret_t");
  new TCanvas();
  h11->GetXaxis()->SetTitle("p, GeV/c");
  h11->GetYaxis()->SetTitle("entries");
  h11->GetYaxis()->CenterTitle();
  h11->GetYaxis()->SetTitleOffset(1.25);
  h11->GetYaxis()->SetNdivisions(409);
  h12->SetFillColor(1);
  h12->SetFillStyle(3003);
  h11->Draw(); h12->Draw("same");
  leg = new TLegend(0.45,0.65,0.70,0.75);
  leg->AddEntry(h11,"spectator");
  leg->AddEntry(h12,"recoil");
  leg->SetFillColor(0);
  leg->SetTextAlign(22);
  leg->Draw();
  printTeX("spec_reco_p");
  new TCanvas();
  h21->GetXaxis()->SetTitle("p, GeV/c");
  h21->GetYaxis()->SetTitle("entries");
  h21->GetYaxis()->CenterTitle();
  h21->GetYaxis()->SetTitleOffset(1.25);
  h22->SetFillColor(1);
  h22->SetFillStyle(3003);
  h21->Draw(); h22->Draw("same");
  leg = new TLegend(0.55,0.45,0.80,0.55);
  leg->AddEntry(h21,"spectator");
  leg->AddEntry(h22,"recoil");
  leg->SetFillColor(0);
  leg->SetTextAlign(22);
  leg->Draw();
  TLatex l; l.DrawLatex(0.635,125,Form("#theta_{2p} < %.0g#circ", theta_max));
  printTeX("spec_reco_p_5");
  new TCanvas();
  h31->GetXaxis()->SetTitle("cos #theta");
  h31->GetYaxis()->SetTitle("entries");
  h31->GetYaxis()->CenterTitle();
  h31->GetYaxis()->SetTitleOffset(1.25);
  h31->GetXaxis()->SetNdivisions(505);
  h32->SetFillColor(1);
  h32->SetFillStyle(3003);
  h31->Draw(); h32->Draw("same");
  leg = new TLegend(0.25,0.70,0.50,0.80);
  leg->AddEntry(h31,"spectator");
  leg->AddEntry(h32,"recoil");
  leg->SetFillColor(0);
  leg->SetTextAlign(22);
  leg->Draw();
  l.DrawLatex(0.9998,70,Form("#theta_{2p} < %.0g#circ", theta_max));
  printTeX("spec_reco_cost_5");
  new TCanvas();
  Int_t pm[2] = {h41->FindBin(0.04), h41->FindBin(0.14)};
  Double_t norm = h41->Integral(pm[0],pm[1])/h42->Integral(pm[0],pm[1]);
  for (Int_t ib = 1; ib <= h42->GetNbinsX(); ib++)
    h42->SetBinContent(ib, h42->GetBinContent(ib)*norm);
  h41->GetXaxis()->SetTitle("p_{spec}, GeV/c");
  h41->GetXaxis()->SetNdivisions(507);
  h41->GetYaxis()->SetTitle("entries");
  h41->GetYaxis()->CenterTitle();
  h41->GetYaxis()->SetTitleOffset(1.15);
  h41->GetYaxis()->SetNdivisions(310);
  h42->SetLineStyle(2);
  h41->Draw(); h42->Draw("same");
  TBox box; box.SetFillColor(1); box.SetFillStyle(3003);
  for (Int_t ib = h42->FindBin(0.21); ib <= h42->GetNbinsX(); ib++)
    box.DrawBox(h42->GetBinLowEdge(ib),
                h41->GetBinContent(ib)*0.99,
                h42->GetBinWidth(ib) + h42->GetBinLowEdge(ib),
                h42->GetBinContent(ib)*1.01);
  leg = new TLegend(0.50,0.65,0.80,0.80);
  leg->AddEntry(h41,"charge exchange");
  leg->AddEntry(h42,"charge retention");
  leg->SetFillColor(0);
  leg->Draw();
  printTeX("resonance_spec");
  can = new TCanvas("theta_p","",0,0,640,860);
  h2->GetXaxis()->SetTitle("#theta, degree");
  h2->GetYaxis()->SetTitle("p_{spec}, GeV/c");
  h2->GetYaxis()->CenterTitle();
  h2->GetYaxis()->SetTitleOffset(1.20);
  h2_1 = h2->ProjectionY("h2_1"); h2_1->Rebin();
  h2_1->GetXaxis()->SetTitle("p_{spec}, GeV/c");
  h2_1->GetXaxis()->CenterTitle(kFALSE);
  h2_1->GetYaxis()->SetNdivisions(405);
  h2_2 = h2->ProjectionX("h2_2"); h2_2->Rebin();
  h2_2->GetXaxis()->SetTitle("#theta, degree");
  h2_2->GetYaxis()->SetNdivisions(405);
  Double_t max = TMath::Max(h2_1->GetMaximum(), h2_2->GetMaximum())*1.025;
  h2_1->SetMaximum(max); h2_2->SetMaximum(max);
  can_1 = new TPad("theta_p_1","",0.0,0.5,1.0,1.0);
  can_1->Draw(); can_1->cd(); can_1->SetTopMargin(0.08); h2->Draw();
  can_1->SetGridx(); can_1->SetGridy();
  can->cd();
  can_2 = new TPad("theta_p_2","",0.0,0.0,1.0,0.5);
  can_2->Draw(); can_2->cd();
  can_21 = new TPad("theta_p_21","",0.0,0.0,0.5,1.0);
  can_21->Draw(); can_21->cd(); can_21->SetTopMargin(0.04); h2_1->Draw();
  can_2->cd();
  can_22 = new TPad("theta_p_22","",0.5,0.0,1.0,1.0);
  can_22->Draw(); can_22->cd(); can_22->SetTopMargin(0.04); h2_2->Draw();
  can->cd();
  printTeX("theta_p");
  can->Print("theta_p.png");
  new TCanvas();
  h5->GetXaxis()->SetTitle("#phi, degree");
  h5->GetYaxis()->SetTitle("entries");
  h5->GetYaxis()->CenterTitle();
  h5->GetYaxis()->SetTitleOffset(1.25);
  h5->GetYaxis()->SetNdivisions(407);
  h5->GetXaxis()->SetNdivisions(-204);
  h5->SetMinimum(1); h5->SetMaximum(h5->GetMaximum()*1.25);
  h5->Draw();
  printTeX("phi_recoil");
  new TCanvas();
  h61->GetXaxis()->SetTitle("p, GeV/c");
  h61->GetXaxis()->SetNdivisions(407);
  h61->GetYaxis()->SetTitle("entries");
  h61->GetYaxis()->CenterTitle();
  h61->GetYaxis()->SetTitleOffset(1.35);
  h61->GetYaxis()->SetNdivisions(407);
  gStyle->SetHatchesSpacing(0.75);
  h61->SetFillColor(kGray+2); h61->SetFillStyle(3345);
  h63->SetFillColor(kGray+2); h63->SetFillStyle(3354);
  h61->Draw(); h62->Draw("same"); h63->Draw("same");
  leg = new TLegend(0.40,0.55,0.65,0.70);
  leg->AddEntry(h61,"spectator");
  leg->AddEntry(h62,"recoil");
  leg->AddEntry(h63,"scattering");
  leg->SetFillColor(0);
  leg->SetTextAlign(22);
  leg->Draw();
  printTeX("spec_reco_scat");
}
