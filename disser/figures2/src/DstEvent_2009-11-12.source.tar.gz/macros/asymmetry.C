// Author: Jan Musinsky
// 28/10/2009

void asymmetry()
{
  // charge retention variable bining
  const Int_t nbins = 24;
  Double_t xbins[nbins+1] = {0.000,0.015,0.025,0.034,0.042,0.050,0.058,0.067,
                             0.077,0.088,0.099,0.110,0.120,0.130,0.140,0.150,
                             0.165,0.180,0.195,0.210,0.225,0.240,0.255,0.270,
                             0.3000001};
  // charge exchange variable bining
  Double_t xbins2[nbins/2+1];
  for (Int_t ib = 0; ib < nbins/2+1; ib++) xbins2[ib] = xbins[ib*2];
  // histograms
  TH1F *his_ret[4], *his_chex[4], *his_asym[4];
  for (Int_t ih = 0; ih < 4; ih++) {
    his_ret[ih] = new TH1F(Form("h_ret%d",ih),"",nbins,xbins);
    his_chex[ih] = new TH1F(Form("h_chex%d",ih),"",nbins/2,xbins2);
  }
  // calculate asymmetry
  TLorentzVector target, spectator, scattering;
  TVector3 q;
  Double_t alpha, t2, edge = TMath::Pi()/2;
  Bool_t is_chex;

  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    tree->GetEntry(i);
    // all values in ALab
    spectator  = event->ALabType(TDstEvent::kSpec);
    scattering = event->ALabType(TDstEvent::kScat);
    target.SetVectMag(event->GetTrack(0)->ALab3(), mass_p);
    q = target.Vect() - scattering.Vect();
    alpha = (spectator.Vect()).Angle(q);
    t2 = TMath::Abs((target - scattering)*(target - scattering)); // invariant
    is_chex = (elist->GetIndex(i) != -1);

    if (t2 < 0.1) {
      if (is_chex) {
        if (alpha < edge) his_chex[0]->Fill(spectator.P());
        else his_chex[1]->Fill(spectator.P());
      }
      else {
        if (alpha < edge) his_ret[0]->Fill(spectator.P());
        else his_ret[1]->Fill(spectator.P());
      }
    }
    else if (t2 < 0.3) {
      if (is_chex) {
        if (alpha < edge) his_chex[2]->Fill(spectator.P());
        else his_chex[3]->Fill(spectator.P());
      }
      else {
        if (alpha < edge) his_ret[2]->Fill(spectator.P());
        else his_ret[3]->Fill(spectator.P());
      }
    }
  }

  // charge exchange, |t| < 0.1
  his_asym[0] = (TH1F *)his_chex[0]->GetAsymmetry(his_chex[1]);
  // charge exchange, 0.1 < |t| < 0.3
  his_asym[1] = (TH1F *)his_chex[2]->GetAsymmetry(his_chex[3]);
  // charge retention, |t| < 0.1
  his_asym[2] = (TH1F *)his_ret[0]->GetAsymmetry(his_ret[1]);
  // charge retention, 0.1 < |t| < 0.3
  his_asym[3] = (TH1F *)his_ret[2]->GetAsymmetry(his_ret[3]);
  // !!!!!
  his_asym[3]->Add((TF1* )gROOT->GetFunction("pol0"), -0.035);
  for (Int_t ih = 0; ih < 4; ih++) his_asym[ih]->SetName(Form("h_asym%d", ih));

  // drawing
  gStyle->SetOptStat(0);
  his_asym[0]->SetMarkerStyle(4); his_asym[1]->SetMarkerStyle(4);
  his_asym[2]->SetMarkerStyle(8); his_asym[3]->SetMarkerStyle(8);
  his_asym[2]->SetMaximum(1.0); his_asym[2]->SetMinimum(-1.0);
  his_asym[3]->SetMaximum(1.0); his_asym[3]->SetMinimum(-1.0);
  his_asym[2]->SetLabelOffset(0.015, "Y");
  his_asym[3]->SetLabelOffset(0.015, "Y");
  his_asym[2]->SetNdivisions(404, "X"); his_asym[2]->SetNdivisions(404, "Y");
  his_asym[3]->SetNdivisions(404, "X"); his_asym[3]->SetNdivisions(404, "Y");
  his_asym[2]->SetTickLength(0.0, "X"); his_asym[2]->SetLabelSize(0.0, "X");
  his_asym[3]->GetXaxis()->SetTitle("p_{spec}, GeV/c");
  his_asym[3]->SetTitleOffset(1.10, "X");

  TLine line; TLatex latex; TGaxis axis;
  line.SetLineStyle(3); latex.SetTextSize(0.04);
  can = new TCanvas("asym","",0,0,600,800);
  can_1 = new TPad("asym_1","",0.0,0.5,1.0,1.0);
  can_1->SetFillStyle(4000); can_1->SetBottomMargin(0.0);
  can_1->Draw(); can_1->cd(); his_asym[2]->Draw(); his_asym[0]->Draw("same");
  line.DrawLine(0.0,0.0,0.3,0.0);
  latex.DrawLatex(0.025,0.750,"#left|t#right| < 0.1 (GeV/c)^{2}");
  can->cd();
  can_2 = new TPad("asym_2","",0.0,0.0,1.0,0.5);
  can_2->SetFillStyle(4000); can_2->SetTopMargin(0.0);
  can_2->Draw(); can_2->cd(); his_asym[3]->Draw(); his_asym[1]->Draw("same");
  line.DrawLine(0.0,0.0,0.3,0.0);
  latex.DrawLatex(0.025,0.750,"0.1 <  #left|t#right| < 0.3 (GeV/c)^{2}");
  leg = new TLegend(0.60,0.25,0.85,0.35);
  leg->AddEntry(his_asym[2],"charge retention","P");
  leg->AddEntry(his_asym[0],"charge exchange","P");
  leg->SetFillColor(0);
  leg->Draw();
  can->cd();
  axis.SetTickSize(0.015); axis.SetLabelSize(0.0);
  axis.DrawAxis(0.1,0.5,0.9,0.5,0.00,0.30,404,"S+-");
  latex.SetTextAngle(90); latex.SetTextSize(0.03);
  latex.DrawLatex(0.04,0.42,"A s y m m e t r y");
  printTeX("asymmetry_alpha");
}
