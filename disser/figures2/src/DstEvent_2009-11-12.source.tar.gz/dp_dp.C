// Author: Jan Musinsky
// 10/11/2009

{
  event = new TDstEvent;
  TFile *file = new TFile("dst/all2pr.root","READ");
  if (file->IsZombie()) {
    Printf("create root's DST from all2pr.dst:");
    Printf("event->DstToTree(\"/free1/dst/dp/all2pr.dst\")");
    Printf("and move to \"dst\" directory");
    return;
  }
  tree = (TTree*)file->Get("dpDst");
  tree->SetBranchAddress("DstEvent", &event);

  TLorentzVector target(0,0,0,mass_p);
  Double_t phi, t, t_min = 0.08; // real calculated with t_min = 0.06
  TH1F *h1 = new TH1F("h1","",50,-180,180);
  TH1F *h2 = new TH1F("h2","",50,-180,180);
  TH1F *ht = new TH1F("ht","",80,0,0.2);

  for (Int_t i = 0; i < tree->GetEntries(); i++) {
    tree->GetEntry(i);
    // only dp -> dp channel
    if ((event->GetHyp() != 1) && (event->GetHyp() != 2)) continue;
    t = -((target - event->Lab(2))*(target - event->Lab(2))); // target - p
    ht->Fill(t);
    phi = event->Lab(2).Phi()*TMath::RadToDeg();
    if (t < t_min) h1->Fill(phi);
    else h2->Fill(phi);
  }

  Double_t norm, phi_min = -60, phi_max = 60;
  h1->Fit("pol0", "QN", "", phi_min, phi_max);
  norm = ((TF1* )gROOT->GetFunction("pol0"))->GetParameter(0);
  h2->Fit("pol0", "QN", "", phi_min, phi_max);
  norm = norm - ((TF1* )gROOT->GetFunction("pol0"))->GetParameter(0);
  for (Int_t ib = 1; ib <= h2->GetNbinsX(); ib++)
    h2->SetBinContent(ib, h2->GetBinContent(ib) + norm);

  gStyle->SetOptStat(0);
  h1->GetXaxis()->SetTitle("#phi, degree");
  h1->GetYaxis()->SetTitle("entries");
  h1->GetYaxis()->CenterTitle();
  h1->GetYaxis()->SetTitleOffset(1.00);
  h1->GetYaxis()->SetNdivisions(407);
  h1->GetXaxis()->SetNdivisions(-204);
  h1->SetMinimum(1); h1->SetMaximum(h1->GetMaximum()*1.15);
  h1->SetFillColor(1); h1->SetFillStyle(3003);
  h1->Draw(); h2->Draw("same");
  leg = new TLegend(0.33,0.15,0.66,0.27);
  leg->AddEntry(h2,"#left|t#right| > 0.06 (GeV/c)^{2} ");
  leg->AddEntry(h1,"#left|t#right| < 0.06 (GeV/c)^{2} ");
  leg->SetFillColor(0); leg->SetTextAlign(22); leg->SetTextSize(0.04);
  leg->Draw();
  printTeX("phi_elastic");
  new TCanvas();
  TF1 *ex = new TF1("ex","[0]*exp(-([1]*x + [2]*(x*x)))");
  ex->SetLineWidth(1);
  Double_t tmin = 0.06, tmax = ht->GetXaxis()->GetXmax();
  ht->Fit("ex","Q","",tmin,tmax);
  TF1 *ex2 = ex->Clone("ex2");
  ex2->SetLineStyle(2);
  ex2->SetFillColor(1);
  ex2->SetFillStyle(3003);
  ex2->SetRange(0,tmin*1.10);
  ex2->Draw("same");
  ht->SetMaximum(ex->Eval(0)*1.05);
  ht->SetFillColor(10);
  ht->Draw("same");
  TGaxis axis;
  axis->DrawAxis(0,0.1,tmax,0.1,0,tmax,409);
  ht->GetXaxis()->SetTitle("#left|t#right|, (GeV/c)^{2}");
  ht->GetYaxis()->SetTitle("entries");
  ht->GetYaxis()->CenterTitle();
  ht->GetYaxis()->SetTitleOffset(1.10);
  ht->GetYaxis()->SetNdivisions(406);
  ht->GetXaxis()->SetNdivisions(axis.GetNdiv());
  leg = new TLegend(0.45,0.57,0.75,0.70);
  leg->AddEntry(ht,"dp  elastic entries");
  leg->AddEntry(ex2,"missing entries");
  leg->SetFillColor(0); leg->SetTextAlign(22);
  leg->Draw();
  printTeX("dp_dp_t");
}
