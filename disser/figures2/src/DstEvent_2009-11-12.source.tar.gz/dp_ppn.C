// Author: Jan Musinsky
// 01/10/2009

{
  event = new TDstEvent;
  TFile *file = new TFile("dst/allppn.root","READ");
  if (file->IsZombie()) {
    Printf("create root's DST from allppn.dst:");
    Printf("event->DstToTree(\"/free1/dst/dp/allppn.dst\")");
    Printf("and move to \"dst\" directory");
    return;
  }
  tree = (TTree*)file->Get("dpDst");
  tree->SetBranchAddress("DstEvent", &event);
  elist = (TEventList*)file->Get("chex");

  gROOT->LoadMacro("macros/ppn.C");
  gROOT->LoadMacro("macros/asymmetry.C");
  gROOT->LoadMacro("macros/dp_two_protons.C");
}
