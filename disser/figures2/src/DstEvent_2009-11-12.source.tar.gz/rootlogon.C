// Author: Jan Musinsky
// 01/10/2009

{
  if (gROOT->GetClass("TDstEvent")) {
    Printf("DstEvent libraries was already loaded");
    return;
  }

  gSystem->AddIncludePath("-Iinclude");
  gSystem->Load("libPhysics.so");
  gSystem->Load("libTree.so");
  gSystem->Load("lib/libDstEvent.so");
  Double_t mass_p = 0.93827;

  gROOT->SetStyle("Plain"); // Default
  gROOT->LoadMacro("$ROOTSYS/macros/printTeX.C");
}
